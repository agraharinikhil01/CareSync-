import React, { useState } from 'react';
import Modal from './Modal';
import { Plus, Trash2, Printer, Activity, CheckCircle2 } from 'lucide-react';
import { createPrescriptionApi } from '../api/endpoints';

export const PrescriptionGeneratorModal = ({ isOpen, onClose, appointment, onSuccess }) => {
  const [diagnosis, setDiagnosis] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [advice, setAdvice] = useState('Take medicines on time, drink adequate fluids, and rest.');
  const [followUpDate, setFollowUpDate] = useState('');
  const [testInput, setTestInput] = useState('');
  const [tests, setTests] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [medicines, setMedicines] = useState([
    { name: '', dosage: '', frequency: 'Twice daily (1-0-1)', duration: '5 days', instructions: 'After meals' },
  ]);

  const handleAddMedicine = () => {
    setMedicines([
      ...medicines,
      { name: '', dosage: '', frequency: 'Once daily', duration: '5 days', instructions: 'After meals' },
    ]);
  };

  const handleRemoveMedicine = (index) => {
    if (medicines.length === 1) return;
    setMedicines(medicines.filter((_, idx) => idx !== index));
  };

  const handleMedicineChange = (index, field, value) => {
    const updated = [...medicines];
    updated[index][field] = value;
    setMedicines(updated);
  };

  const handleAddTest = () => {
    if (testInput.trim()) {
      setTests([...tests, testInput.trim()]);
      setTestInput('');
    }
  };

  const handleRemoveTest = (idx) => {
    setTests(tests.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!diagnosis.trim()) {
      setError('Please provide a medical diagnosis');
      return;
    }

    const invalidMedicine = medicines.some((m) => !m.name.trim() || !m.dosage.trim());
    if (invalidMedicine) {
      setError('Please fill name and dosage for all prescribed medicines');
      return;
    }

    try {
      setLoading(true);
      const payload = {
        appointmentId: appointment._id,
        patientId: appointment.patientId._id || appointment.patientId,
        diagnosis,
        symptoms,
        medicines,
        tests,
        advice,
        followUpDate: followUpDate || null,
      };

      const res = await createPrescriptionApi(payload);
      if (res.data.success) {
        onSuccess(res.data.data);
        onClose();
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create prescription');
    } finally {
      setLoading(false);
    }
  };

  if (!appointment) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Generate Electronic Prescription (E-Rx)" maxWidth="max-w-3xl">
      <form onSubmit={handleSubmit} className="space-y-5">
        {error && (
          <div className="p-3 text-xs font-semibold text-red-700 bg-red-50 border border-red-200 rounded-xl">
            {error}
          </div>
        )}

        {/* Patient Summary Header */}
        <div className="bg-sky-50/70 p-4 rounded-xl border border-sky-100 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div>
            <span className="text-slate-500 font-medium">Patient Name:</span>
            <span className="font-bold text-slate-800 ml-1.5">{appointment.patientId?.name}</span>
          </div>
          <div>
            <span className="text-slate-500 font-medium">Email / Contact:</span>
            <span className="font-bold text-slate-800 ml-1.5">{appointment.patientId?.email}</span>
          </div>
          <div>
            <span className="text-slate-500 font-medium">Appointment Type:</span>
            <span className="font-bold text-sky-700 ml-1.5">{appointment.type}</span>
          </div>
        </div>

        {/* Clinical Diagnosis & Symptoms */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Diagnosis *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Acute Bronchitis / Type 2 Diabetes"
              value={diagnosis}
              onChange={(e) => setDiagnosis(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Chief Symptoms
            </label>
            <input
              type="text"
              placeholder="e.g. Persistent dry cough, 101 F fever"
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Medicines Section */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Rx - Prescribed Medicines *
            </label>
            <button
              type="button"
              onClick={handleAddMedicine}
              className="inline-flex items-center gap-1 text-xs font-semibold text-sky-600 hover:text-sky-700 bg-sky-50 px-2.5 py-1 rounded-lg border border-sky-200"
            >
              <Plus className="w-3.5 h-3.5" /> Add Medicine
            </button>
          </div>

          <div className="space-y-3">
            {medicines.map((med, idx) => (
              <div key={idx} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-600">Medicine #{idx + 1}</span>
                  {medicines.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveMedicine(idx)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-2">
                  <div className="md:col-span-2">
                    <input
                      type="text"
                      placeholder="Medicine Name (e.g. Amoxicillin)"
                      value={med.name}
                      onChange={(e) => handleMedicineChange(idx, 'name', e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-sky-500 focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Dosage (500mg)"
                      value={med.dosage}
                      onChange={(e) => handleMedicineChange(idx, 'dosage', e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-sky-500 focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Frequency (1-0-1)"
                      value={med.frequency}
                      onChange={(e) => handleMedicineChange(idx, 'frequency', e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-sky-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Duration (5 days)"
                      value={med.duration}
                      onChange={(e) => handleMedicineChange(idx, 'duration', e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-sky-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <input
                    type="text"
                    placeholder="Special Instructions (e.g. Take after meal with warm water)"
                    value={med.instructions}
                    onChange={(e) => handleMedicineChange(idx, 'instructions', e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg focus:ring-1 focus:ring-sky-500 focus:outline-none text-xs"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Diagnostic Tests & Advice */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Recommended Lab Tests
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. CBC, Serum Creatinine"
                value={testInput}
                onChange={(e) => setTestInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddTest();
                  }
                }}
                className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none"
              />
              <button
                type="button"
                onClick={handleAddTest}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold"
              >
                Add
              </button>
            </div>
            {tests.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {tests.map((t, i) => (
                  <span
                    key={i}
                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-sky-100 text-sky-800 rounded-md text-xs font-medium"
                  >
                    {t}
                    <button type="button" onClick={() => handleRemoveTest(i)} className="text-sky-600 hover:text-red-600">
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Follow-up Review Date
            </label>
            <input
              type="date"
              value={followUpDate}
              onChange={(e) => setFollowUpDate(e.target.value)}
              className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            General Medical Advice & Precautions
          </label>
          <textarea
            rows="2"
            value={advice}
            onChange={(e) => setAdvice(e.target.value)}
            className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 focus:outline-none"
          ></textarea>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-xl"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-sm font-semibold shadow-md disabled:opacity-50"
          >
            <CheckCircle2 className="w-4 h-4" />
            {loading ? 'Submitting Rx...' : 'Issue Prescription'}
          </button>
        </div>
      </form>
    </Modal>
  );
};

// Prescription Viewer / Print Modal
export const PrescriptionViewerModal = ({ isOpen, onClose, prescription }) => {
  if (!prescription) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Medical Prescription Sheet" maxWidth="max-w-2xl">
      <div className="printable-area bg-white p-6 sm:p-8 rounded-xl border border-slate-200 space-y-6 text-slate-800">
        {/* Hospital Letterhead Header */}
        <div className="flex items-center justify-between pb-5 border-b-2 border-sky-600">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-sky-600 flex items-center justify-center text-white">
              <Activity className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-sky-900 tracking-tight">CareSync Multi-Specialty Hospital</h2>
              <p className="text-xs text-slate-500">100 Healthcare Avenue, NY 10001 | 24/7 Helpline: +1 (555) 010-9999</p>
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs font-bold uppercase tracking-wider text-sky-700 bg-sky-50 px-2.5 py-1 rounded-md border border-sky-200">
              Official Rx
            </span>
          </div>
        </div>

        {/* Doctor & Patient Info Bar */}
        <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
          <div>
            <p className="text-slate-500">Treating Doctor:</p>
            <p className="font-bold text-slate-900 text-sm">{prescription.doctorId?.name || 'Dr. Medical Officer'}</p>
            <p className="text-slate-600">{prescription.doctorId?.email}</p>
          </div>
          <div className="text-right">
            <p className="text-slate-500">Patient Details:</p>
            <p className="font-bold text-slate-900 text-sm">{prescription.patientId?.name}</p>
            <p className="text-slate-600">{new Date(prescription.date).toLocaleDateString()}</p>
          </div>
        </div>

        {/* Diagnosis */}
        <div className="text-xs space-y-1">
          <span className="font-bold text-slate-700 uppercase tracking-wider">Clinical Diagnosis:</span>
          <p className="text-slate-900 font-semibold text-sm bg-sky-50/50 p-2.5 rounded-lg border border-sky-100">
            {prescription.diagnosis}
          </p>
          {prescription.symptoms && (
            <p className="text-slate-500 mt-1">
              <span className="font-medium">Symptoms Noted:</span> {prescription.symptoms}
            </p>
          )}
        </div>

        {/* Medicines Table */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-2xl font-serif font-black text-sky-700">℞</span>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700">Medicines & Dosage Schedule</span>
          </div>

          <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
            <table className="w-full text-left">
              <thead className="bg-slate-100 font-bold text-slate-700 border-b border-slate-200">
                <tr>
                  <th className="p-2.5">Medicine</th>
                  <th className="p-2.5">Dosage</th>
                  <th className="p-2.5">Frequency</th>
                  <th className="p-2.5">Duration</th>
                  <th className="p-2.5">Instructions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {prescription.medicines?.map((med, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="p-2.5 font-bold text-slate-900">{med.name}</td>
                    <td className="p-2.5 font-medium">{med.dosage}</td>
                    <td className="p-2.5 text-slate-600">{med.frequency}</td>
                    <td className="p-2.5 text-slate-600">{med.duration}</td>
                    <td className="p-2.5 text-slate-500 italic">{med.instructions}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Tests & Advice */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          {prescription.tests && prescription.tests.length > 0 && (
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="font-bold text-slate-700 block mb-1.5">Required Lab Tests:</span>
              <ul className="list-disc list-inside space-y-1 text-slate-600">
                {prescription.tests.map((test, i) => (
                  <li key={i}>{test}</li>
                ))}
              </ul>
            </div>
          )}

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-700 block mb-1.5">Doctor Advice:</span>
            <p className="text-slate-600 leading-relaxed">{prescription.advice}</p>
            {prescription.followUpDate && (
              <p className="mt-2 text-sky-700 font-semibold">
                Follow-up Date: {new Date(prescription.followUpDate).toLocaleDateString()}
              </p>
            )}
          </div>
        </div>

        {/* Signatures & Footer */}
        <div className="pt-8 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <p>Generated by CareSync Electronic Health Record System</p>
          <div className="text-center">
            <div className="border-b border-slate-400 w-36 mb-1"></div>
            <p className="font-semibold text-slate-700">Doctor Signature</p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="no-print mt-6 flex items-center justify-end gap-3">
        <button
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-xl"
        >
          Close
        </button>
        <button
          onClick={handlePrint}
          className="inline-flex items-center gap-2 px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-sm font-semibold shadow-md"
        >
          <Printer className="w-4 h-4" /> Print Prescription
        </button>
      </div>
    </Modal>
  );
};
