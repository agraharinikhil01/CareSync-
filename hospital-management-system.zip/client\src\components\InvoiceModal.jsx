import React, { useState } from 'react';
import Modal from './Modal';
import { Plus, Trash2, Printer, CheckCircle, CreditCard, Activity } from 'lucide-react';
import { createInvoiceApi, updatePaymentStatusApi } from '../api/endpoints';

// Invoice Creation Form Modal
export const InvoiceGeneratorModal = ({ isOpen, onClose, patients = [], doctors = [], onSuccess }) => {
  const [patientId, setPatientId] = useState('');
  const [doctorId, setDoctorId] = useState('');
  const [discountAmount, setDiscountAmount] = useState(0);
  const [paymentStatus, setPaymentStatus] = useState('Pending');
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [items, setItems] = useState([
    { description: 'General Consultation Fee', quantity: 1, unitPrice: 500 },
  ]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAddItem = () => {
    setItems([...items, { description: '', quantity: 1, unitPrice: 0 }]);
  };

  const handleRemoveItem = (index) => {
    if (items.length === 1) return;
    setItems(items.filter((_, idx) => idx !== index));
  };

  const handleItemChange = (index, field, value) => {
    const updated = [...items];
    updated[index][field] = value;
    setItems(updated);
  };

  const subTotal = items.reduce((acc, item) => acc + (Number(item.quantity || 1) * Number(item.unitPrice || 0)), 0);
  const tax = Math.round(subTotal * 0.05);
  const total = Math.max(0, subTotal + tax - Number(discountAmount || 0));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!patientId) {
      setError('Please select a patient');
      return;
    }

    const invalid = items.some((i) => !i.description.trim() || Number(i.unitPrice) < 0);
    if (invalid) {
      setError('Please provide valid descriptions and amounts for all items');
      return;
    }

    try {
      setLoading(true);
      const payload = {
        patientId,
        doctorId: doctorId || null,
        items,
        discountAmount: Number(discountAmount || 0),
        paymentStatus,
        paymentMethod: paymentStatus === 'Paid' ? paymentMethod : 'Pending Selection',
      };

      const res = await createInvoiceApi(payload);
      if (res.data.success) {
        onSuccess(res.data.data);
        onClose();
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create invoice');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Generate Hospital Billing Invoice" maxWidth="max-w-2xl">
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 text-xs font-semibold text-red-700 bg-red-50 border border-red-200 rounded-xl">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Select Patient *
            </label>
            <select
              required
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 focus:outline-none"
            >
              <option value="">-- Choose Patient --</option>
              {patients.map((p) => (
                <option key={p.userId?._id || p._id} value={p.userId?._id || p._id}>
                  {p.userId?.name || p.name} ({p.userId?.email || p.email})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Attending Doctor (Optional)
            </label>
            <select
              value={doctorId}
              onChange={(e) => setDoctorId(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 focus:outline-none"
            >
              <option value="">-- None / General Hospital --</option>
              {doctors.map((d) => (
                <option key={d.userId?._id || d._id} value={d.userId?._id || d._id}>
                  {d.userId?.name || d.name} ({d.specialization})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Itemized charges */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Itemized Charges & Services
            </label>
            <button
              type="button"
              onClick={handleAddItem}
              className="inline-flex items-center gap-1 text-xs font-semibold text-sky-600 bg-sky-50 hover:bg-sky-100 px-2.5 py-1 rounded-lg border border-sky-200"
            >
              <Plus className="w-3.5 h-3.5" /> Add Line Item
            </button>
          </div>

          <div className="space-y-2.5">
            {items.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Description (e.g. ICU Bed Charges, MRI Scan)"
                  value={item.description}
                  onChange={(e) => handleItemChange(idx, 'description', e.target.value)}
                  className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-sky-500 focus:outline-none"
                  required
                />
                <input
                  type="number"
                  placeholder="Qty"
                  min="1"
                  value={item.quantity}
                  onChange={(e) => handleItemChange(idx, 'quantity', e.target.value)}
                  className="w-16 px-2 py-2 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-sky-500 focus:outline-none text-center"
                />
                <input
                  type="number"
                  placeholder="Price ($)"
                  min="0"
                  value={item.unitPrice}
                  onChange={(e) => handleItemChange(idx, 'unitPrice', e.target.value)}
                  className="w-24 px-2 py-2 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-sky-500 focus:outline-none text-right"
                  required
                />
                {items.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveItem(idx)}
                    className="p-2 text-red-500 hover:text-red-700 rounded-lg hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Calculation Summary */}
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs text-slate-600">
          <div className="flex justify-between">
            <span>Subtotal:</span>
            <span className="font-semibold text-slate-800">${subTotal.toLocaleString()}</span>
          </div>
          <div className="flex justify-between">
            <span>Tax (5% GST/Service):</span>
            <span className="font-semibold text-slate-800">${tax.toLocaleString()}</span>
          </div>
          <div className="flex justify-between items-center">
            <span>Discount Amount ($):</span>
            <input
              type="number"
              min="0"
              value={discountAmount}
              onChange={(e) => setDiscountAmount(e.target.value)}
              className="w-24 px-2 py-1 text-xs border border-slate-300 rounded-lg text-right focus:ring-1 focus:ring-sky-500"
            />
          </div>
          <div className="flex justify-between pt-2 border-t border-slate-200 text-sm font-extrabold text-slate-900">
            <span>Final Billable Amount:</span>
            <span className="text-sky-700">${total.toLocaleString()}</span>
          </div>
        </div>

        {/* Payment options */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Payment Status
            </label>
            <select
              value={paymentStatus}
              onChange={(e) => setPaymentStatus(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500"
            >
              <option value="Pending">Pending (Pay Later)</option>
              <option value="Paid">Paid Immediately</option>
            </select>
          </div>

          {paymentStatus === 'Paid' && (
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Payment Method
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500"
              >
                <option value="Cash">Cash Counter</option>
                <option value="Credit/Debit Card">Credit / Debit Card</option>
                <option value="UPI/Online">UPI / Online Gateway</option>
                <option value="Health Insurance">Health Insurance Claim</option>
              </select>
            </div>
          )}
        </div>

        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-xl"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-sm font-semibold shadow-md disabled:opacity-50"
          >
            {loading ? 'Creating...' : 'Generate Invoice'}
          </button>
        </div>
      </form>
    </Modal>
  );
};

// Printable Invoice Modal & Instant Payment Viewer
export const InvoiceViewerModal = ({ isOpen, onClose, invoice, onPaymentSuccess }) => {
  const [payLoading, setPayLoading] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState('UPI/Online');

  if (!invoice) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleQuickPay = async () => {
    try {
      setPayLoading(true);
      const res = await updatePaymentStatusApi(invoice._id, {
        paymentStatus: 'Paid',
        paymentMethod: selectedMethod,
        transactionId: `TXN-${Date.now()}`,
      });
      if (res.data.success && onPaymentSuccess) {
        onPaymentSuccess(res.data.data);
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Payment processing failed');
    } finally {
      setPayLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Hospital Invoice: ${invoice.invoiceNumber}`} maxWidth="max-w-2xl">
      <div className="printable-area bg-white p-6 rounded-xl border border-slate-200 space-y-6 text-slate-800 text-xs">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-600 text-white flex items-center justify-center">
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">CareSync Hospital Ltd.</h3>
              <p className="text-slate-500">Official Tax Invoice & Receipt</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-base font-black text-sky-700">{invoice.invoiceNumber}</p>
            <p className="text-slate-500">Date: {new Date(invoice.invoiceDate).toLocaleDateString()}</p>
          </div>
        </div>

        {/* Patient & Doctor details */}
        <div className="grid grid-cols-2 gap-4 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
          <div>
            <span className="font-bold text-slate-600 uppercase tracking-wider block mb-1">Billed To:</span>
            <p className="font-bold text-slate-900 text-sm">{invoice.patientId?.name}</p>
            <p className="text-slate-600">{invoice.patientId?.email}</p>
            <p className="text-slate-600">{invoice.patientId?.phone}</p>
          </div>
          <div className="text-right">
            <span className="font-bold text-slate-600 uppercase tracking-wider block mb-1">Payment Status:</span>
            <span
              className={`inline-block px-3 py-1 rounded-full font-bold text-xs ${
                invoice.paymentStatus === 'Paid'
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}
            >
              {invoice.paymentStatus}
            </span>
            {invoice.paymentMethod && (
              <p className="text-slate-500 mt-1 font-medium">Method: {invoice.paymentMethod}</p>
            )}
            {invoice.transactionId && (
              <p className="text-slate-400 font-mono text-[10px]">Txn ID: {invoice.transactionId}</p>
            )}
          </div>
        </div>

        {/* Line Items Table */}
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-slate-100 font-bold text-slate-700 border-b border-slate-200">
              <tr>
                <th className="p-2.5">Service Description</th>
                <th className="p-2.5 text-center">Qty</th>
                <th className="p-2.5 text-right">Unit Price</th>
                <th className="p-2.5 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {invoice.items?.map((item, idx) => (
                <tr key={idx}>
                  <td className="p-2.5 font-medium text-slate-800">{item.description}</td>
                  <td className="p-2.5 text-center text-slate-600">{item.quantity}</td>
                  <td className="p-2.5 text-right text-slate-600">${item.unitPrice?.toLocaleString()}</td>
                  <td className="p-2.5 text-right font-bold text-slate-900">${item.amount?.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Calculation */}
        <div className="space-y-1.5 max-w-xs ml-auto text-right">
          <div className="flex justify-between text-slate-600">
            <span>Subtotal:</span>
            <span className="font-semibold">${invoice.subTotal?.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>Tax (5%):</span>
            <span className="font-semibold">${invoice.taxAmount?.toLocaleString()}</span>
          </div>
          {invoice.discountAmount > 0 && (
            <div className="flex justify-between text-emerald-600">
              <span>Discount Applied:</span>
              <span className="font-semibold">-${invoice.discountAmount?.toLocaleString()}</span>
            </div>
          )}
          <div className="flex justify-between pt-2 border-t border-slate-300 text-sm font-black text-slate-900">
            <span>Total Payable:</span>
            <span className="text-sky-700">${invoice.totalAmount?.toLocaleString()}</span>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-slate-200 text-center text-slate-400 text-[11px]">
          Thank you for trusting CareSync Hospital with your healthcare needs. All invoices are computer-generated.
        </div>
      </div>

      {/* Payment Action Bar */}
      <div className="no-print mt-6 flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-200">
        <div>
          {invoice.paymentStatus !== 'Paid' && (
            <div className="flex items-center gap-2">
              <select
                value={selectedMethod}
                onChange={(e) => setSelectedMethod(e.target.value)}
                className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium"
              >
                <option value="UPI/Online">UPI / Card Gateway</option>
                <option value="Cash">Cash at Counter</option>
                <option value="Health Insurance">Health Insurance</option>
              </select>
              <button
                onClick={handleQuickPay}
                disabled={payLoading}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow disabled:opacity-50"
              >
                <CheckCircle className="w-4 h-4" /> {payLoading ? 'Processing...' : 'Mark as Paid'}
              </button>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-xl"
          >
            Close
          </button>
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow"
          >
            <Printer className="w-4 h-4" /> Print / PDF
          </button>
        </div>
      </div>
    </Modal>
  );
};
