import React, { useState, useEffect } from 'react';
import Navbar from '../../components/Navbar';
import Sidebar from '../../components/Sidebar';
import StatCard from '../../components/StatCard';
import Table from '../../components/Table';
import Modal from '../../components/Modal';
import { PrescriptionViewerModal } from '../../components/PrescriptionModal';
import { InvoiceViewerModal } from '../../components/InvoiceModal';
import {
  getPatientDashboardApi,
  getDoctorsListApi,
  createAppointmentApi,
  getPatientProfileApi,
  updatePatientProfileApi,
  getPrescriptionsApi,
  getInvoicesApi,
  updateAppointmentStatusApi,
} from '../../api/endpoints';
import {
  CalendarCheck,
  FileText,
  CreditCard,
  HeartPulse,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  User,
  Shield,
  Stethoscope,
} from 'lucide-react';

const PatientDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [dashboardData, setDashboardData] = useState(null);
  const [doctors, setDoctors] = useState([]);
  const [prescriptions, setPrescriptions] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  // Booking Form state
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [specializationFilter, setSpecializationFilter] = useState('All');
  const [doctorSearch, setDoctorSearch] = useState('');
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTimeSlot, setBookingTimeSlot] = useState('10:00 AM');
  const [bookingReason, setBookingReason] = useState('');
  const [bookingType, setBookingType] = useState('General Consultation');
  const [bookingSuccessMsg, setBookingSuccessMsg] = useState('');
  const [bookingError, setBookingError] = useState('');
  const [bookingLoading, setBookingLoading] = useState(false);

  // Modals for viewing Rx and Invoices
  const [viewPrescription, setViewPrescription] = useState(null);
  const [viewInvoice, setViewInvoice] = useState(null);

  // Profile Edit
  const [profileForm, setProfileForm] = useState({
    age: '',
    gender: 'Male',
    bloodGroup: 'B+',
    emergencyContact: { name: '', phone: '', relationship: '' },
    address: { street: '', city: '', state: '', zipCode: '' },
    allergies: '',
  });

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    try {
      setLoading(true);
      if (activeTab === 'overview') {
        const res = await getPatientDashboardApi();
        if (res.data.success) setDashboardData(res.data.data);
      } else if (activeTab === 'book') {
        const res = await getDoctorsListApi();
        if (res.data.success) setDoctors(res.data.data);
      } else if (activeTab === 'prescriptions') {
        const res = await getPrescriptionsApi();
        if (res.data.success) setPrescriptions(res.data.data);
      } else if (activeTab === 'invoices') {
        const res = await getInvoicesApi();
        if (res.data.success) setInvoices(res.data.data);
      } else if (activeTab === 'profile') {
        const res = await getPatientProfileApi();
        if (res.data.success) {
          setProfile(res.data.data);
          setProfileForm({
            age: res.data.data.age || '',
            gender: res.data.data.gender || 'Male',
            bloodGroup: res.data.data.bloodGroup || 'B+',
            emergencyContact: res.data.data.emergencyContact || { name: '', phone: '', relationship: '' },
            address: res.data.data.address || { street: '', city: '', state: '', zipCode: '' },
            allergies: res.data.data.allergies?.join(', ') || '',
          });
        }
      }
    } catch (error) {
      console.error('Error loading patient data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBookAppointment = async (e) => {
    e.preventDefault();
    setBookingError('');
    setBookingSuccessMsg('');

    if (!selectedDoctor || !bookingDate || !bookingReason) {
      setBookingError('Please select a doctor, date, and appointment reason');
      return;
    }

    try {
      setBookingLoading(true);
      const res = await createAppointmentApi({
        doctorId: selectedDoctor.userId?._id || selectedDoctor.userId,
        date: bookingDate,
        timeSlot: bookingTimeSlot,
        reason: bookingReason,
        type: bookingType,
      });

      if (res.data.success) {
        setBookingSuccessMsg('Appointment booked successfully! Our staff will confirm your slot.');
        setSelectedDoctor(null);
        setBookingReason('');
      }
    } catch (err) {
      setBookingError(err.response?.data?.message || 'Failed to book appointment');
    } finally {
      setBookingLoading(false);
    }
  };

  const handleCancelAppointment = async (id) => {
    if (!window.confirm('Are you sure you want to cancel this appointment?')) return;
    try {
      const res = await updateAppointmentStatusApi(id, { status: 'Cancelled' });
      if (res.data.success) {
        fetchData();
      }
    } catch (err) {
      alert('Failed to cancel appointment');
    }
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        age: Number(profileForm.age),
        gender: profileForm.gender,
        bloodGroup: profileForm.bloodGroup,
        emergencyContact: profileForm.emergencyContact,
        address: profileForm.address,
        allergies: profileForm.allergies.split(',').map((s) => s.trim()).filter(Boolean),
      };
      const res = await updatePatientProfileApi(payload);
      if (res.data.success) {
        alert('Health profile updated successfully');
        setProfile(res.data.data);
      }
    } catch (err) {
      alert('Failed to update profile');
    }
  };

  const filteredDoctors = doctors.filter((doc) => {
    const matchSpec = specializationFilter === 'All' || doc.specialization.toLowerCase().includes(specializationFilter.toLowerCase());
    const matchSearch = doc.userId?.name?.toLowerCase().includes(doctorSearch.toLowerCase()) || doc.specialization.toLowerCase().includes(doctorSearch.toLowerCase());
    return matchSpec && matchSearch;
  });

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Patient Health Portal</h1>
                  <p className="text-sm text-slate-500">Appointments, prescriptions, billing records and health history</p>
                </div>
                <button
                  onClick={() => setActiveTab('book')}
                  className="inline-flex items-center gap-2 px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow transition"
                >
                  <CalendarCheck className="w-4 h-4" /> Book New Consultation
                </button>
              </div>

              {/* KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard
                  title="Upcoming Appointments"
                  value={dashboardData?.metrics?.upcomingCount || 0}
                  subtitle="Scheduled visits"
                  icon={CalendarCheck}
                  color="sky"
                />
                <StatCard
                  title="Prescriptions Issued"
                  value={dashboardData?.metrics?.totalPrescriptions || 0}
                  subtitle="Active & past medications"
                  icon={FileText}
                  color="emerald"
                />
                <StatCard
                  title="Total Consultations"
                  value={dashboardData?.metrics?.totalAppointments || 0}
                  subtitle="Lifetime hospital visits"
                  icon={HeartPulse}
                  color="purple"
                />
                <StatCard
                  title="Pending Invoices"
                  value={`$${(dashboardData?.metrics?.pendingBills || 0).toLocaleString()}`}
                  subtitle="Outstanding balance"
                  icon={CreditCard}
                  color={dashboardData?.metrics?.pendingBills > 0 ? 'rose' : 'emerald'}
                />
              </div>

              {/* Upcoming Appointments */}
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <h3 className="font-bold text-slate-900 text-base">Your Upcoming Consultations</h3>
                  <button onClick={() => setActiveTab('book')} className="text-xs font-bold text-sky-600">
                    Find Doctor →
                  </button>
                </div>

                {dashboardData?.upcomingAppointments && dashboardData.upcomingAppointments.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {dashboardData.upcomingAppointments.map((app) => (
                      <div key={app._id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/60 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center font-bold">
                              <Stethoscope className="w-5 h-5" />
                            </div>
                            <div>
                              <p className="font-bold text-slate-900 text-sm">{app.doctorId?.name}</p>
                              <p className="text-xs text-slate-500">{app.type}</p>
                            </div>
                          </div>
                          <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-sky-100 text-sky-800">
                            {app.timeSlot}
                          </span>
                        </div>

                        <div className="text-xs bg-white p-2.5 rounded-xl border border-slate-200">
                          <p className="text-slate-500 font-medium">Date: <span className="font-bold text-slate-800">{new Date(app.date).toLocaleDateString()}</span></p>
                          <p className="text-slate-600 mt-1"><span className="font-medium">Reason:</span> {app.reason}</p>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs">
                          <span className="px-2 py-0.5 rounded-full font-bold bg-amber-100 text-amber-800">{app.status}</span>
                          <button
                            onClick={() => handleCancelAppointment(app._id)}
                            className="text-xs font-bold text-red-600 hover:text-red-700"
                          >
                            Cancel Appointment
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-8 text-center text-slate-400 font-medium text-sm">
                    No upcoming appointments scheduled. Need care? Book with our specialists today.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: BOOK APPOINTMENT */}
          {activeTab === 'book' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">Find a Specialist & Book Appointment</h1>
                <p className="text-sm text-slate-500">Select department, check doctor qualifications & pick your consultation slot</p>
              </div>

              {bookingSuccessMsg && (
                <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  {bookingSuccessMsg}
                </div>
              )}

              {bookingError && (
                <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-xs font-bold">
                  {bookingError}
                </div>
              )}

              {/* Doctor Directory Filters */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-wrap items-center gap-3">
                <div className="flex-1 min-w-[200px] relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    placeholder="Search doctor by name or specialty..."
                    value={doctorSearch}
                    onChange={(e) => setDoctorSearch(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-slate-500" />
                  <select
                    value={specializationFilter}
                    onChange={(e) => setSpecializationFilter(e.target.value)}
                    className="px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 font-medium"
                  >
                    <option value="All">All Departments</option>
                    <option value="Cardiologist">Cardiology</option>
                    <option value="Neurologist">Neurology</option>
                    <option value="Pediatrician">Pediatrics</option>
                    <option value="General">General Medicine</option>
                  </select>
                </div>
              </div>

              {/* Doctor Selection Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredDoctors.map((doc) => {
                  const isSelected = selectedDoctor?._id === doc._id;
                  return (
                    <div
                      key={doc._id}
                      onClick={() => setSelectedDoctor(doc)}
                      className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'border-sky-500 bg-sky-50/50 shadow-md ring-2 ring-sky-500/20'
                          : 'border-slate-200 bg-white hover:border-sky-300 shadow-sm'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-sky-600 to-primary-400 text-white font-black flex items-center justify-center text-base shadow-sm">
                            {doc.userId?.name?.charAt(0) || 'D'}
                          </div>
                          <div>
                            <h4 className="font-bold text-slate-900 text-sm">{doc.userId?.name}</h4>
                            <p className="text-xs font-semibold text-sky-700">{doc.specialization}</p>
                          </div>
                        </div>
                      </div>

                      <div className="mt-3 space-y-1.5 text-xs text-slate-600">
                        <p>Department: <span className="font-medium text-slate-800">{doc.department}</span></p>
                        <p>Experience: <span className="font-medium text-slate-800">{doc.experienceYears} Years</span></p>
                        <p>Consultation Fee: <span className="font-extrabold text-slate-900">${doc.consultationFee}</span></p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                        <span className="text-slate-400 font-medium">Room: {doc.roomNumber || 'Op-Desk'}</span>
                        <button
                          type="button"
                          className={`px-3 py-1.5 rounded-xl font-bold text-xs ${
                            isSelected
                              ? 'bg-sky-600 text-white'
                              : 'bg-slate-100 text-slate-700 hover:bg-sky-50 hover:text-sky-700'
                          }`}
                        >
                          {isSelected ? '✓ Selected' : 'Select Doctor'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Booking Confirmation Box */}
              {selectedDoctor && (
                <div className="bg-white p-6 rounded-3xl border border-sky-200 shadow-lg space-y-4">
                  <h3 className="text-base font-bold text-slate-900">
                    Schedule with {selectedDoctor.userId?.name} ({selectedDoctor.specialization})
                  </h3>

                  <form onSubmit={handleBookAppointment} className="space-y-4 text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="font-bold text-slate-700 uppercase">Consultation Date *</label>
                        <input
                          type="date"
                          required
                          min={new Date().toISOString().split('T')[0]}
                          value={bookingDate}
                          onChange={(e) => setBookingDate(e.target.value)}
                          className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 mt-1"
                        />
                      </div>

                      <div>
                        <label className="font-bold text-slate-700 uppercase">Preferred Time Slot *</label>
                        <select
                          value={bookingTimeSlot}
                          onChange={(e) => setBookingTimeSlot(e.target.value)}
                          className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 mt-1"
                        >
                          <option value="09:00 AM">09:00 AM</option>
                          <option value="10:00 AM">10:00 AM</option>
                          <option value="11:30 AM">11:30 AM</option>
                          <option value="02:00 PM">02:00 PM</option>
                          <option value="03:30 PM">03:30 PM</option>
                          <option value="04:30 PM">04:30 PM</option>
                        </select>
                      </div>

                      <div>
                        <label className="font-bold text-slate-700 uppercase">Visit Type</label>
                        <select
                          value={bookingType}
                          onChange={(e) => setBookingType(e.target.value)}
                          className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 mt-1"
                        >
                          <option value="General Consultation">General Consultation</option>
                          <option value="Follow-up">Follow-up</option>
                          <option value="Routine Checkup">Routine Checkup</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="font-bold text-slate-700 uppercase">Reason for Consultation *</label>
                      <textarea
                        rows="2"
                        required
                        placeholder="Briefly describe your symptoms or reason for visit..."
                        value={bookingReason}
                        onChange={(e) => setBookingReason(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 mt-1"
                      ></textarea>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <p className="text-slate-500">
                        Consultation fee: <span className="font-bold text-slate-900">${selectedDoctor.consultationFee}</span> (Payable on counter/online)
                      </p>
                      <button
                        type="submit"
                        disabled={bookingLoading}
                        className="px-6 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl shadow-md disabled:opacity-50"
                      >
                        {bookingLoading ? 'Confirming...' : 'Confirm Appointment'}
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: PRESCRIPTIONS */}
          {activeTab === 'prescriptions' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">My Medical Prescriptions</h1>
                <p className="text-sm text-slate-500">Digital records of doctor diagnosis, medicines and instructions</p>
              </div>

              <Table
                columns={[
                  {
                    header: 'Doctor Name',
                    render: (row) => <span className="font-bold text-slate-900">{row.doctorId?.name}</span>,
                  },
                  {
                    header: 'Diagnosis',
                    accessor: 'diagnosis',
                  },
                  {
                    header: 'Medicines Prescribed',
                    render: (row) => (
                      <span className="text-xs text-slate-600 font-medium">
                        {row.medicines?.map((m) => m.name).join(', ') || 'None'}
                      </span>
                    ),
                  },
                  {
                    header: 'Date',
                    render: (row) => <span className="text-xs text-slate-500">{new Date(row.date).toLocaleDateString()}</span>,
                  },
                  {
                    header: 'Action',
                    render: (row) => (
                      <button
                        onClick={() => setViewPrescription(row)}
                        className="px-3 py-1.5 text-xs font-bold text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-lg border border-sky-200"
                      >
                        View & Download Rx
                      </button>
                    ),
                  },
                ]}
                data={prescriptions}
              />
            </div>
          )}

          {/* TAB 4: BILLING & INVOICES */}
          {activeTab === 'invoices' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">My Invoices & Payments</h1>
                <p className="text-sm text-slate-500">Itemized hospital bills, receipts, and online payment clearance</p>
              </div>

              <Table
                columns={[
                  {
                    header: 'Invoice #',
                    render: (row) => <span className="font-mono font-bold text-sky-700">{row.invoiceNumber}</span>,
                  },
                  {
                    header: 'Date',
                    render: (row) => <span className="text-xs text-slate-500">{new Date(row.invoiceDate).toLocaleDateString()}</span>,
                  },
                  {
                    header: 'Amount',
                    render: (row) => <span className="font-black text-slate-900">${row.totalAmount?.toLocaleString()}</span>,
                  },
                  {
                    header: 'Status',
                    render: (row) => (
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                          row.paymentStatus === 'Paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {row.paymentStatus}
                      </span>
                    ),
                  },
                  {
                    header: 'Actions',
                    render: (row) => (
                      <button
                        onClick={() => setViewInvoice(row)}
                        className="px-3 py-1 text-xs font-bold text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-lg border border-sky-200"
                      >
                        {row.paymentStatus === 'Paid' ? 'View Receipt' : 'Pay Now / View'}
                      </button>
                    ),
                  },
                ]}
                data={invoices}
              />
            </div>
          )}

          {/* TAB 5: HEALTH PROFILE & EHR */}
          {activeTab === 'profile' && (
            <div className="space-y-6 max-w-4xl">
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900">Health Profile & Emergency Contacts</h1>
                <p className="text-sm text-slate-500">Update medical history, vital stats and emergency information</p>
              </div>

              <form onSubmit={handleUpdateProfile} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-5 text-xs">
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="font-bold text-slate-700 uppercase">Age</label>
                    <input
                      type="number"
                      value={profileForm.age}
                      onChange={(e) => setProfileForm({ ...profileForm, age: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 mt-1"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 uppercase">Gender</label>
                    <select
                      value={profileForm.gender}
                      onChange={(e) => setProfileForm({ ...profileForm, gender: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 mt-1"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 uppercase">Blood Group</label>
                    <select
                      value={profileForm.bloodGroup}
                      onChange={(e) => setProfileForm({ ...profileForm, bloodGroup: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 mt-1 font-bold"
                    >
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="O+">O+</option>
                      <option value="O-">O-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 uppercase">Known Drug / Food Allergies</label>
                  <input
                    type="text"
                    placeholder="e.g. Penicillin, Peanuts, Sulfa (comma separated)"
                    value={profileForm.allergies}
                    onChange={(e) => setProfileForm({ ...profileForm, allergies: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 mt-1"
                  />
                </div>

                <div className="border-t border-slate-100 pt-4 space-y-3">
                  <h4 className="font-bold text-slate-800 uppercase tracking-wider text-xs">Emergency Contact Details</h4>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="font-medium text-slate-600">Contact Name</label>
                      <input
                        type="text"
                        value={profileForm.emergencyContact?.name || ''}
                        onChange={(e) =>
                          setProfileForm({
                            ...profileForm,
                            emergencyContact: { ...profileForm.emergencyContact, name: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl mt-1"
                      />
                    </div>
                    <div>
                      <label className="font-medium text-slate-600">Phone</label>
                      <input
                        type="text"
                        value={profileForm.emergencyContact?.phone || ''}
                        onChange={(e) =>
                          setProfileForm({
                            ...profileForm,
                            emergencyContact: { ...profileForm.emergencyContact, phone: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl mt-1"
                      />
                    </div>
                    <div>
                      <label className="font-medium text-slate-600">Relationship</label>
                      <input
                        type="text"
                        value={profileForm.emergencyContact?.relationship || ''}
                        onChange={(e) =>
                          setProfileForm({
                            ...profileForm,
                            emergencyContact: { ...profileForm.emergencyContact, relationship: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl mt-1"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-3">
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl shadow-md"
                  >
                    Save Health Profile
                  </button>
                </div>
              </form>
            </div>
          )}
        </main>
      </div>

      {/* PRESCRIPTION VIEWER MODAL */}
      <PrescriptionViewerModal
        isOpen={!!viewPrescription}
        onClose={() => setViewPrescription(null)}
        prescription={viewPrescription}
      />

      {/* INVOICE VIEWER & PAYMENT MODAL */}
      <InvoiceViewerModal
        isOpen={!!viewInvoice}
        onClose={() => setViewInvoice(null)}
        invoice={viewInvoice}
        onPaymentSuccess={() => {
          fetchData();
          setViewInvoice(null);
        }}
      />
    </div>
  );
};

export default PatientDashboard;
