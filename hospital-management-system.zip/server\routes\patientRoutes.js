const express = require('express');
const router = express.Router();
const {
  getPatientProfile,
  updatePatientProfile,
  getPatientDashboard,
  addMedicalRecord,
} = require('../controllers/patientController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.use(protect);

router.get('/profile', getPatientProfile);
router.put('/profile', authorize('patient'), updatePatientProfile);
router.get('/dashboard', authorize('patient'), getPatientDashboard);
router.post('/:id/medical-records', authorize('doctor', 'admin'), addMedicalRecord);

module.exports = router;
