const express = require('express');
const router = express.Router();
const {
  getDashboardStats,
  getAllDoctors,
  createDoctor,
  updateDoctor,
  getAllPatients,
  getAllStaff,
  toggleUserStatus,
} = require('../controllers/adminController');
const { protect, authorize } = require('../middleware/authMiddleware');

// All admin routes require Admin role
router.use(protect);
router.use(authorize('admin'));

router.get('/stats', getDashboardStats);
router.get('/doctors', getAllDoctors);
router.post('/doctors', createDoctor);
router.put('/doctors/:id', updateDoctor);
router.get('/patients', getAllPatients);
router.get('/staff', getAllStaff);
router.patch('/users/:id/toggle-status', toggleUserStatus);

module.exports = router;
